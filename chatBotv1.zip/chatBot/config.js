module.exports = {
    GEMINI_API_KEY: "AIzaSyDGbxGhuYYQ88lD2rQ2IO_2if_l2Sp8Mmo" // Ganti dengan API key Anda
};